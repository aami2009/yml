package io.swagger.api;

import io.swagger.model.Body;
import io.swagger.model.InlineResponse200;
import io.swagger.model.InlineResponse400;
import io.swagger.model.InlineResponse4001;
import io.swagger.model.InlineResponse4002;
import io.swagger.model.InlineResponse401;
import io.swagger.model.InlineResponse403;
import io.swagger.model.ProjectCarHistoryResponse;
import io.swagger.model.ProjectColorRequest;
import io.swagger.model.ProjectColorResponse;
import io.swagger.model.ProjectHistoryResponse;
import io.swagger.model.ProjectLocationRequest;
import io.swagger.model.ProjectLocationResponse;
import io.swagger.model.ProjectRequest;
import io.swagger.model.ProjectResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

@Controller
public class ProjectApiController implements ProjectApi {

    private static final Logger log = LoggerFactory.getLogger(ProjectApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public ProjectApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<ProjectColorResponse> createColor(@ApiParam(value = "Project Id",required=true) @PathVariable("projectId") Long projectId,@ApiParam(value = "product object that needs to be updated" ,required=true )  @Valid @RequestBody ProjectColorRequest body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectColorResponse>(objectMapper.readValue("{  \"code\" : \"LINE_EXTENSION\",  \"releaseName\" : \"pending\",  \"Id\" : 789,  \"projectId\" : 894}", ProjectColorResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectColorResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectColorResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectLocationResponse> createLocation(@ApiParam(value = "project object that needs to be added" ,required=true )  @Valid @RequestBody ProjectLocationRequest body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectLocationResponse>(objectMapper.readValue("{  \"regionCode\" : \"BA59\",  \"localeCode\" : \"US\",  \"colorID\" : 789,  \"id\" : 789,  \"projectId\" : 789}", ProjectLocationResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectLocationResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectLocationResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectRequest> createProject(@ApiParam(value = "project object that needs to be added" ,required=true )  @Valid @RequestBody ProjectRequest body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectRequest>(objectMapper.readValue("{  \"code\" : \"456\",  \"productId\" : 789,  \"releaseName\" : \"Beats Pro\",  \"colorLocationMap\" : [ \"redloc, greenloc\", \"redloc, greenloc\" ],  \"modelNumber\" : \"789\",  \"type\" : \"LINE_EXTENSION\",  \"assignedUsers\" : {    \"role\" : \"APPROVER\",    \"id\" : 12342342  },  \"status\" : \"PENDING\"}", ProjectRequest.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectRequest>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectRequest>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectCarHistoryResponse> getProCartonHistory(@ApiParam(value = "Project carton Id",required=true) @PathVariable("project_carton_id") Long projectCartonId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectCarHistoryResponse>(objectMapper.readValue("{  \"pageCount\" : 1,  \"data\" : [ {    \"id\" : 5,    \"type\" : \"goldenSampleRejection\",    \"comment\" : \"MPN value not correctly validated\",    \"currentStatus\" : \"pendingApproval\",    \"newStatus\" : \"pendingGoldenSubmission\",    \"currentAssignee\" : 49,    \"newAssignee\" : 44,    \"submittedBy\" : 49,    \"submittedDate\" : \"2020-06-09 12:52:22.000\"  }, {    \"id\" : 4,    \"type\" : \"goldenSampleRejection\",    \"comment\" : \"\",    \"currentStatus\" : \"pendingGoldenSubmission\",    \"newStatus\" : \"pendingApproval\",    \"currentAssignee\" : 44,    \"newAssignee\" : 49,    \"submittedBy\" : 44,    \"submittedDate\" : \"2020-06-08 4:52:22.000\"  } ],  \"rowCount\" : 5}", ProjectCarHistoryResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectCarHistoryResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectCarHistoryResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectHistoryResponse> getProjectHistory(@ApiParam(value = "Project Id",required=true) @PathVariable("projectId") Long projectId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectHistoryResponse>(objectMapper.readValue("{  \"pageCount\" : \"1\",  \"data\" : [ {    \"productId\" : \"BA59\",    \"id\" : 789,    \"projectID\" : \"US\",    \"actions\" : [ {      \"submittedBy\" : 111,      \"colorLocations\" : [ {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      }, {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      } ],      \"comment\" : \"Archived project because reason\",      \"type\" : \"restoreProject\",      \"submittedDate\" : \"2020-06-09 12:52:22.000\"    }, {      \"submittedBy\" : 111,      \"colorLocations\" : [ {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      }, {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      } ],      \"comment\" : \"Archived project because reason\",      \"type\" : \"restoreProject\",      \"submittedDate\" : \"2020-06-09 12:52:22.000\"    } ]  }, {    \"productId\" : \"BA59\",    \"id\" : 789,    \"projectID\" : \"US\",    \"actions\" : [ {      \"submittedBy\" : 111,      \"colorLocations\" : [ {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      }, {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      } ],      \"comment\" : \"Archived project because reason\",      \"type\" : \"restoreProject\",      \"submittedDate\" : \"2020-06-09 12:52:22.000\"    }, {      \"submittedBy\" : 111,      \"colorLocations\" : [ {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      }, {        \"color\" : \"7897878\",        \"locations\" : [ \"98437, 12342349\", \"98437, 12342349\" ]      } ],      \"comment\" : \"Archived project because reason\",      \"type\" : \"restoreProject\",      \"submittedDate\" : \"2020-06-09 12:52:22.000\"    } ]  } ],  \"rowCount\" : \"10\"}", ProjectHistoryResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectHistoryResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectHistoryResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<InlineResponse200> getRoleByprojectId(@ApiParam(value = "Project Id",required=true) @PathVariable("projectId") Long projectId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<InlineResponse200>(objectMapper.readValue("{  \"role\" : \"admin\",  \"projectId\" : 12345}", InlineResponse200.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<InlineResponse200>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<InlineResponse200>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectResponse> getprojectById(@ApiParam(value = "ID of project to return",required=true) @PathVariable("projectId") Long projectId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectResponse>(objectMapper.readValue("{  \"code\" : \"456\",  \"productId\" : 894,  \"releaseName\" : \"Beats Pro\",  \"colorLocationMap\" : [ {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  }, {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  } ],  \"modelNumber\" : \"789\",  \"Id\" : 789,  \"type\" : \"LINE_EXTENSION\",  \"assignedUsers\" : [ {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  }, {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  } ],  \"status\" : \"pending\",  \"cartons\" : [ {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  }, {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  } ]}", ProjectResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectResponse> listOfproject() {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectResponse>(objectMapper.readValue("{  \"code\" : \"456\",  \"productId\" : 894,  \"releaseName\" : \"Beats Pro\",  \"colorLocationMap\" : [ {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  }, {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  } ],  \"modelNumber\" : \"789\",  \"Id\" : 789,  \"type\" : \"LINE_EXTENSION\",  \"assignedUsers\" : [ {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  }, {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  } ],  \"status\" : \"pending\",  \"cartons\" : [ {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  }, {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  } ]}", ProjectResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectColorResponse> updateColor(@ApiParam(value = "Color Id",required=true) @PathVariable("colorId") Long colorId,@ApiParam(value = "product object that needs to be updated" ,required=true )  @Valid @RequestBody Body body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectColorResponse>(objectMapper.readValue("{  \"code\" : \"LINE_EXTENSION\",  \"releaseName\" : \"pending\",  \"Id\" : 789,  \"projectId\" : 894}", ProjectColorResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectColorResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectColorResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ProjectResponse> updateproject(@ApiParam(value = "Route to update a project’s metadata, including the assigned users to a project." ,required=true )  @Valid @RequestBody ProjectResponse body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ProjectResponse>(objectMapper.readValue("{  \"code\" : \"456\",  \"productId\" : 894,  \"releaseName\" : \"Beats Pro\",  \"colorLocationMap\" : [ {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  }, {    \"color\" : {      \"code\" : \"CA\",      \"releaseName\" : \"Black\",      \"id\" : 6666,      \"projectId\" : 999    },    \"location\" : [ {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    }, {      \"regionCode\" : \"LL\",      \"localeCode\" : \"US\",      \"id\" : 444,      \"projectId\" : 999    } ]  } ],  \"modelNumber\" : \"789\",  \"Id\" : 789,  \"type\" : \"LINE_EXTENSION\",  \"assignedUsers\" : [ {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  }, {    \"firstName\" : \"Jon\",    \"lastName\" : \"Smith\",    \"role\" : \"ADMIN\",    \"displayName\" : \"Jonny\",    \"id\" : 111,    \"email\" : \"jon@apple.com\"  } ],  \"status\" : \"pending\",  \"cartons\" : [ {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  }, {    \"gs1Label\" : 789,    \"color\" : 111,    \"projectMPN\" : \"projectMPN\",    \"description\" : \"US, Black\",    \"snListLabel\" : 120,    \"location\" : \"US\",    \"id\" : 789,    \"validationStatus\" : \"pendingApproval\",    \"catonItem\" : [ \"item1, item2\", \"item1, item2\" ]  } ]}", ProjectResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ProjectResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ProjectResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
