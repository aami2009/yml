package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectRequestAssignedUsers;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectRequest
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectRequest   {
  @JsonProperty("productId")
  private Long productId = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("assignedUsers")
  private ProjectRequestAssignedUsers assignedUsers = null;

  @JsonProperty("code")
  private String code = null;

  @JsonProperty("colorLocationMap")
  @Valid
  private List<String> colorLocationMap = null;

  @JsonProperty("releaseName")
  private String releaseName = null;

  @JsonProperty("modelNumber")
  private String modelNumber = null;

  public ProjectRequest productId(Long productId) {
    this.productId = productId;
    return this;
  }

  /**
   * Get productId
   * @return productId
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getProductId() {
    return productId;
  }

  public void setProductId(Long productId) {
    this.productId = productId;
  }

  public ProjectRequest type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(example = "LINE_EXTENSION", value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ProjectRequest status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(example = "PENDING", value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public ProjectRequest assignedUsers(ProjectRequestAssignedUsers assignedUsers) {
    this.assignedUsers = assignedUsers;
    return this;
  }

  /**
   * Get assignedUsers
   * @return assignedUsers
  **/
  @ApiModelProperty(value = "")

  @Valid

  public ProjectRequestAssignedUsers getAssignedUsers() {
    return assignedUsers;
  }

  public void setAssignedUsers(ProjectRequestAssignedUsers assignedUsers) {
    this.assignedUsers = assignedUsers;
  }

  public ProjectRequest code(String code) {
    this.code = code;
    return this;
  }

  /**
   * project code
   * @return code
  **/
  @ApiModelProperty(example = "456", value = "project code")


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ProjectRequest colorLocationMap(List<String> colorLocationMap) {
    this.colorLocationMap = colorLocationMap;
    return this;
  }

  public ProjectRequest addColorLocationMapItem(String colorLocationMapItem) {
    if (this.colorLocationMap == null) {
      this.colorLocationMap = new ArrayList<String>();
    }
    this.colorLocationMap.add(colorLocationMapItem);
    return this;
  }

  /**
   * Get colorLocationMap
   * @return colorLocationMap
  **/
  @ApiModelProperty(value = "")


  public List<String> getColorLocationMap() {
    return colorLocationMap;
  }

  public void setColorLocationMap(List<String> colorLocationMap) {
    this.colorLocationMap = colorLocationMap;
  }

  public ProjectRequest releaseName(String releaseName) {
    this.releaseName = releaseName;
    return this;
  }

  /**
   * project release name
   * @return releaseName
  **/
  @ApiModelProperty(example = "Beats Pro", value = "project release name")


  public String getReleaseName() {
    return releaseName;
  }

  public void setReleaseName(String releaseName) {
    this.releaseName = releaseName;
  }

  public ProjectRequest modelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
    return this;
  }

  /**
   * project model number
   * @return modelNumber
  **/
  @ApiModelProperty(example = "789", value = "project model number")


  public String getModelNumber() {
    return modelNumber;
  }

  public void setModelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectRequest projectRequest = (ProjectRequest) o;
    return Objects.equals(this.productId, projectRequest.productId) &&
        Objects.equals(this.type, projectRequest.type) &&
        Objects.equals(this.status, projectRequest.status) &&
        Objects.equals(this.assignedUsers, projectRequest.assignedUsers) &&
        Objects.equals(this.code, projectRequest.code) &&
        Objects.equals(this.colorLocationMap, projectRequest.colorLocationMap) &&
        Objects.equals(this.releaseName, projectRequest.releaseName) &&
        Objects.equals(this.modelNumber, projectRequest.modelNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(productId, type, status, assignedUsers, code, colorLocationMap, releaseName, modelNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectRequest {\n");
    
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    assignedUsers: ").append(toIndentedString(assignedUsers)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    colorLocationMap: ").append(toIndentedString(colorLocationMap)).append("\n");
    sb.append("    releaseName: ").append(toIndentedString(releaseName)).append("\n");
    sb.append("    modelNumber: ").append(toIndentedString(modelNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

