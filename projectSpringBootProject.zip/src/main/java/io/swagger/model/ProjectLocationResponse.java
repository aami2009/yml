package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectLocationResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectLocationResponse   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("regionCode")
  private String regionCode = null;

  @JsonProperty("localeCode")
  private String localeCode = null;

  @JsonProperty("projectId")
  private Long projectId = null;

  @JsonProperty("colorID")
  private Long colorID = null;

  public ProjectLocationResponse id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProjectLocationResponse regionCode(String regionCode) {
    this.regionCode = regionCode;
    return this;
  }

  /**
   * Get regionCode
   * @return regionCode
  **/
  @ApiModelProperty(example = "BA59", value = "")


  public String getRegionCode() {
    return regionCode;
  }

  public void setRegionCode(String regionCode) {
    this.regionCode = regionCode;
  }

  public ProjectLocationResponse localeCode(String localeCode) {
    this.localeCode = localeCode;
    return this;
  }

  /**
   * Get localeCode
   * @return localeCode
  **/
  @ApiModelProperty(example = "US", value = "")


  public String getLocaleCode() {
    return localeCode;
  }

  public void setLocaleCode(String localeCode) {
    this.localeCode = localeCode;
  }

  public ProjectLocationResponse projectId(Long projectId) {
    this.projectId = projectId;
    return this;
  }

  /**
   * Get projectId
   * @return projectId
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getProjectId() {
    return projectId;
  }

  public void setProjectId(Long projectId) {
    this.projectId = projectId;
  }

  public ProjectLocationResponse colorID(Long colorID) {
    this.colorID = colorID;
    return this;
  }

  /**
   * Get colorID
   * @return colorID
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getColorID() {
    return colorID;
  }

  public void setColorID(Long colorID) {
    this.colorID = colorID;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectLocationResponse projectLocationResponse = (ProjectLocationResponse) o;
    return Objects.equals(this.id, projectLocationResponse.id) &&
        Objects.equals(this.regionCode, projectLocationResponse.regionCode) &&
        Objects.equals(this.localeCode, projectLocationResponse.localeCode) &&
        Objects.equals(this.projectId, projectLocationResponse.projectId) &&
        Objects.equals(this.colorID, projectLocationResponse.colorID);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, regionCode, localeCode, projectId, colorID);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectLocationResponse {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    regionCode: ").append(toIndentedString(regionCode)).append("\n");
    sb.append("    localeCode: ").append(toIndentedString(localeCode)).append("\n");
    sb.append("    projectId: ").append(toIndentedString(projectId)).append("\n");
    sb.append("    colorID: ").append(toIndentedString(colorID)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

