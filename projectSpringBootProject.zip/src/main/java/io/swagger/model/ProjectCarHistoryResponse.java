package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectCarHistoryResponseData;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectCarHistoryResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectCarHistoryResponse   {
  @JsonProperty("data")
  @Valid
  private List<ProjectCarHistoryResponseData> data = null;

  @JsonProperty("pageCount")
  private Long pageCount = null;

  @JsonProperty("rowCount")
  private Long rowCount = null;

  public ProjectCarHistoryResponse data(List<ProjectCarHistoryResponseData> data) {
    this.data = data;
    return this;
  }

  public ProjectCarHistoryResponse addDataItem(ProjectCarHistoryResponseData dataItem) {
    if (this.data == null) {
      this.data = new ArrayList<ProjectCarHistoryResponseData>();
    }
    this.data.add(dataItem);
    return this;
  }

  /**
   * Get data
   * @return data
  **/
  @ApiModelProperty(example = "[{\"id\":5,\"type\":\"goldenSampleRejection\",\"comment\":\"MPN value not correctly validated\",\"currentStatus\":\"pendingApproval\",\"newStatus\":\"pendingGoldenSubmission\",\"currentAssignee\":49,\"newAssignee\":44,\"submittedBy\":49,\"submittedDate\":\"2020-06-09 12:52:22.000\"},{\"id\":4,\"type\":\"goldenSampleRejection\",\"comment\":\"\",\"currentStatus\":\"pendingGoldenSubmission\",\"newStatus\":\"pendingApproval\",\"currentAssignee\":44,\"newAssignee\":49,\"submittedBy\":44,\"submittedDate\":\"2020-06-08 4:52:22.000\"}]", value = "")

  @Valid

  public List<ProjectCarHistoryResponseData> getData() {
    return data;
  }

  public void setData(List<ProjectCarHistoryResponseData> data) {
    this.data = data;
  }

  public ProjectCarHistoryResponse pageCount(Long pageCount) {
    this.pageCount = pageCount;
    return this;
  }

  /**
   * Get pageCount
   * @return pageCount
  **/
  @ApiModelProperty(example = "1", value = "")


  public Long getPageCount() {
    return pageCount;
  }

  public void setPageCount(Long pageCount) {
    this.pageCount = pageCount;
  }

  public ProjectCarHistoryResponse rowCount(Long rowCount) {
    this.rowCount = rowCount;
    return this;
  }

  /**
   * Get rowCount
   * @return rowCount
  **/
  @ApiModelProperty(example = "5", value = "")


  public Long getRowCount() {
    return rowCount;
  }

  public void setRowCount(Long rowCount) {
    this.rowCount = rowCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectCarHistoryResponse projectCarHistoryResponse = (ProjectCarHistoryResponse) o;
    return Objects.equals(this.data, projectCarHistoryResponse.data) &&
        Objects.equals(this.pageCount, projectCarHistoryResponse.pageCount) &&
        Objects.equals(this.rowCount, projectCarHistoryResponse.rowCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(data, pageCount, rowCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectCarHistoryResponse {\n");
    
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    pageCount: ").append(toIndentedString(pageCount)).append("\n");
    sb.append("    rowCount: ").append(toIndentedString(rowCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

