package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectHistoryResponseColorLocations
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectHistoryResponseColorLocations   {
  @JsonProperty("color")
  private String color = null;

  @JsonProperty("locations")
  @Valid
  private List<String> locations = null;

  public ProjectHistoryResponseColorLocations color(String color) {
    this.color = color;
    return this;
  }

  /**
   * Get color
   * @return color
  **/
  @ApiModelProperty(example = "7897878", value = "")


  public String getColor() {
    return color;
  }

  public void setColor(String color) {
    this.color = color;
  }

  public ProjectHistoryResponseColorLocations locations(List<String> locations) {
    this.locations = locations;
    return this;
  }

  public ProjectHistoryResponseColorLocations addLocationsItem(String locationsItem) {
    if (this.locations == null) {
      this.locations = new ArrayList<String>();
    }
    this.locations.add(locationsItem);
    return this;
  }

  /**
   * Get locations
   * @return locations
  **/
  @ApiModelProperty(value = "")


  public List<String> getLocations() {
    return locations;
  }

  public void setLocations(List<String> locations) {
    this.locations = locations;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectHistoryResponseColorLocations projectHistoryResponseColorLocations = (ProjectHistoryResponseColorLocations) o;
    return Objects.equals(this.color, projectHistoryResponseColorLocations.color) &&
        Objects.equals(this.locations, projectHistoryResponseColorLocations.locations);
  }

  @Override
  public int hashCode() {
    return Objects.hash(color, locations);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectHistoryResponseColorLocations {\n");
    
    sb.append("    color: ").append(toIndentedString(color)).append("\n");
    sb.append("    locations: ").append(toIndentedString(locations)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

