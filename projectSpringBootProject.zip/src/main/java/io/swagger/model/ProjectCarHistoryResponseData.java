package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectCarHistoryResponseData
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectCarHistoryResponseData   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("comment")
  private String comment = null;

  @JsonProperty("currentStatus")
  private String currentStatus = null;

  @JsonProperty("newStatus")
  private String newStatus = null;

  @JsonProperty("currentAssignee")
  private Long currentAssignee = null;

  @JsonProperty("newAssignee")
  private Long newAssignee = null;

  @JsonProperty("submittedBy")
  private Long submittedBy = null;

  @JsonProperty("submittedDate")
  private String submittedDate = null;

  public ProjectCarHistoryResponseData id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "5", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProjectCarHistoryResponseData type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(example = "BA59", value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ProjectCarHistoryResponseData comment(String comment) {
    this.comment = comment;
    return this;
  }

  /**
   * Get comment
   * @return comment
  **/
  @ApiModelProperty(example = "MPN value not correctly validated", value = "")


  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public ProjectCarHistoryResponseData currentStatus(String currentStatus) {
    this.currentStatus = currentStatus;
    return this;
  }

  /**
   * Get currentStatus
   * @return currentStatus
  **/
  @ApiModelProperty(example = "pendingApproval", value = "")


  public String getCurrentStatus() {
    return currentStatus;
  }

  public void setCurrentStatus(String currentStatus) {
    this.currentStatus = currentStatus;
  }

  public ProjectCarHistoryResponseData newStatus(String newStatus) {
    this.newStatus = newStatus;
    return this;
  }

  /**
   * Get newStatus
   * @return newStatus
  **/
  @ApiModelProperty(example = "pendingGoldenSubmission", value = "")


  public String getNewStatus() {
    return newStatus;
  }

  public void setNewStatus(String newStatus) {
    this.newStatus = newStatus;
  }

  public ProjectCarHistoryResponseData currentAssignee(Long currentAssignee) {
    this.currentAssignee = currentAssignee;
    return this;
  }

  /**
   * Get currentAssignee
   * @return currentAssignee
  **/
  @ApiModelProperty(example = "49", value = "")


  public Long getCurrentAssignee() {
    return currentAssignee;
  }

  public void setCurrentAssignee(Long currentAssignee) {
    this.currentAssignee = currentAssignee;
  }

  public ProjectCarHistoryResponseData newAssignee(Long newAssignee) {
    this.newAssignee = newAssignee;
    return this;
  }

  /**
   * Get newAssignee
   * @return newAssignee
  **/
  @ApiModelProperty(example = "44", value = "")


  public Long getNewAssignee() {
    return newAssignee;
  }

  public void setNewAssignee(Long newAssignee) {
    this.newAssignee = newAssignee;
  }

  public ProjectCarHistoryResponseData submittedBy(Long submittedBy) {
    this.submittedBy = submittedBy;
    return this;
  }

  /**
   * Get submittedBy
   * @return submittedBy
  **/
  @ApiModelProperty(example = "49", value = "")


  public Long getSubmittedBy() {
    return submittedBy;
  }

  public void setSubmittedBy(Long submittedBy) {
    this.submittedBy = submittedBy;
  }

  public ProjectCarHistoryResponseData submittedDate(String submittedDate) {
    this.submittedDate = submittedDate;
    return this;
  }

  /**
   * Get submittedDate
   * @return submittedDate
  **/
  @ApiModelProperty(example = "2020-06-09 12:52:22.000", value = "")


  public String getSubmittedDate() {
    return submittedDate;
  }

  public void setSubmittedDate(String submittedDate) {
    this.submittedDate = submittedDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectCarHistoryResponseData projectCarHistoryResponseData = (ProjectCarHistoryResponseData) o;
    return Objects.equals(this.id, projectCarHistoryResponseData.id) &&
        Objects.equals(this.type, projectCarHistoryResponseData.type) &&
        Objects.equals(this.comment, projectCarHistoryResponseData.comment) &&
        Objects.equals(this.currentStatus, projectCarHistoryResponseData.currentStatus) &&
        Objects.equals(this.newStatus, projectCarHistoryResponseData.newStatus) &&
        Objects.equals(this.currentAssignee, projectCarHistoryResponseData.currentAssignee) &&
        Objects.equals(this.newAssignee, projectCarHistoryResponseData.newAssignee) &&
        Objects.equals(this.submittedBy, projectCarHistoryResponseData.submittedBy) &&
        Objects.equals(this.submittedDate, projectCarHistoryResponseData.submittedDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, type, comment, currentStatus, newStatus, currentAssignee, newAssignee, submittedBy, submittedDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectCarHistoryResponseData {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    comment: ").append(toIndentedString(comment)).append("\n");
    sb.append("    currentStatus: ").append(toIndentedString(currentStatus)).append("\n");
    sb.append("    newStatus: ").append(toIndentedString(newStatus)).append("\n");
    sb.append("    currentAssignee: ").append(toIndentedString(currentAssignee)).append("\n");
    sb.append("    newAssignee: ").append(toIndentedString(newAssignee)).append("\n");
    sb.append("    submittedBy: ").append(toIndentedString(submittedBy)).append("\n");
    sb.append("    submittedDate: ").append(toIndentedString(submittedDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

