package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectHistoryResponseData;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectHistoryResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectHistoryResponse   {
  @JsonProperty("data")
  @Valid
  private List<ProjectHistoryResponseData> data = null;

  @JsonProperty("pageCount")
  private String pageCount = null;

  @JsonProperty("rowCount")
  private String rowCount = null;

  public ProjectHistoryResponse data(List<ProjectHistoryResponseData> data) {
    this.data = data;
    return this;
  }

  public ProjectHistoryResponse addDataItem(ProjectHistoryResponseData dataItem) {
    if (this.data == null) {
      this.data = new ArrayList<ProjectHistoryResponseData>();
    }
    this.data.add(dataItem);
    return this;
  }

  /**
   * Get data
   * @return data
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectHistoryResponseData> getData() {
    return data;
  }

  public void setData(List<ProjectHistoryResponseData> data) {
    this.data = data;
  }

  public ProjectHistoryResponse pageCount(String pageCount) {
    this.pageCount = pageCount;
    return this;
  }

  /**
   * Get pageCount
   * @return pageCount
  **/
  @ApiModelProperty(example = "1", value = "")


  public String getPageCount() {
    return pageCount;
  }

  public void setPageCount(String pageCount) {
    this.pageCount = pageCount;
  }

  public ProjectHistoryResponse rowCount(String rowCount) {
    this.rowCount = rowCount;
    return this;
  }

  /**
   * Get rowCount
   * @return rowCount
  **/
  @ApiModelProperty(example = "10", value = "")


  public String getRowCount() {
    return rowCount;
  }

  public void setRowCount(String rowCount) {
    this.rowCount = rowCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectHistoryResponse projectHistoryResponse = (ProjectHistoryResponse) o;
    return Objects.equals(this.data, projectHistoryResponse.data) &&
        Objects.equals(this.pageCount, projectHistoryResponse.pageCount) &&
        Objects.equals(this.rowCount, projectHistoryResponse.rowCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(data, pageCount, rowCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectHistoryResponse {\n");
    
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    pageCount: ").append(toIndentedString(pageCount)).append("\n");
    sb.append("    rowCount: ").append(toIndentedString(rowCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

