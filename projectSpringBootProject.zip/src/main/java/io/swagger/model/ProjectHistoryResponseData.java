package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectHistoryResponseActions;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectHistoryResponseData
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectHistoryResponseData   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("productId")
  private String productId = null;

  @JsonProperty("projectID")
  private String projectID = null;

  @JsonProperty("actions")
  @Valid
  private List<ProjectHistoryResponseActions> actions = null;

  public ProjectHistoryResponseData id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProjectHistoryResponseData productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * Get productId
   * @return productId
  **/
  @ApiModelProperty(example = "BA59", value = "")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public ProjectHistoryResponseData projectID(String projectID) {
    this.projectID = projectID;
    return this;
  }

  /**
   * Get projectID
   * @return projectID
  **/
  @ApiModelProperty(example = "US", value = "")


  public String getProjectID() {
    return projectID;
  }

  public void setProjectID(String projectID) {
    this.projectID = projectID;
  }

  public ProjectHistoryResponseData actions(List<ProjectHistoryResponseActions> actions) {
    this.actions = actions;
    return this;
  }

  public ProjectHistoryResponseData addActionsItem(ProjectHistoryResponseActions actionsItem) {
    if (this.actions == null) {
      this.actions = new ArrayList<ProjectHistoryResponseActions>();
    }
    this.actions.add(actionsItem);
    return this;
  }

  /**
   * Get actions
   * @return actions
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectHistoryResponseActions> getActions() {
    return actions;
  }

  public void setActions(List<ProjectHistoryResponseActions> actions) {
    this.actions = actions;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectHistoryResponseData projectHistoryResponseData = (ProjectHistoryResponseData) o;
    return Objects.equals(this.id, projectHistoryResponseData.id) &&
        Objects.equals(this.productId, projectHistoryResponseData.productId) &&
        Objects.equals(this.projectID, projectHistoryResponseData.projectID) &&
        Objects.equals(this.actions, projectHistoryResponseData.actions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, productId, projectID, actions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectHistoryResponseData {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    projectID: ").append(toIndentedString(projectID)).append("\n");
    sb.append("    actions: ").append(toIndentedString(actions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

