package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectHistoryResponseColorLocations;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectHistoryResponseActions
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectHistoryResponseActions   {
  @JsonProperty("type")
  private String type = null;

  @JsonProperty("submittedDate")
  private String submittedDate = null;

  @JsonProperty("submittedBy")
  private Long submittedBy = null;

  @JsonProperty("comment")
  private String comment = null;

  @JsonProperty("colorLocations")
  @Valid
  private List<ProjectHistoryResponseColorLocations> colorLocations = null;

  public ProjectHistoryResponseActions type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(example = "restoreProject", value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ProjectHistoryResponseActions submittedDate(String submittedDate) {
    this.submittedDate = submittedDate;
    return this;
  }

  /**
   * Get submittedDate
   * @return submittedDate
  **/
  @ApiModelProperty(example = "2020-06-09 12:52:22.000", value = "")


  public String getSubmittedDate() {
    return submittedDate;
  }

  public void setSubmittedDate(String submittedDate) {
    this.submittedDate = submittedDate;
  }

  public ProjectHistoryResponseActions submittedBy(Long submittedBy) {
    this.submittedBy = submittedBy;
    return this;
  }

  /**
   * Get submittedBy
   * @return submittedBy
  **/
  @ApiModelProperty(example = "111", value = "")


  public Long getSubmittedBy() {
    return submittedBy;
  }

  public void setSubmittedBy(Long submittedBy) {
    this.submittedBy = submittedBy;
  }

  public ProjectHistoryResponseActions comment(String comment) {
    this.comment = comment;
    return this;
  }

  /**
   * Get comment
   * @return comment
  **/
  @ApiModelProperty(example = "Archived project because reason", value = "")


  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public ProjectHistoryResponseActions colorLocations(List<ProjectHistoryResponseColorLocations> colorLocations) {
    this.colorLocations = colorLocations;
    return this;
  }

  public ProjectHistoryResponseActions addColorLocationsItem(ProjectHistoryResponseColorLocations colorLocationsItem) {
    if (this.colorLocations == null) {
      this.colorLocations = new ArrayList<ProjectHistoryResponseColorLocations>();
    }
    this.colorLocations.add(colorLocationsItem);
    return this;
  }

  /**
   * Get colorLocations
   * @return colorLocations
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectHistoryResponseColorLocations> getColorLocations() {
    return colorLocations;
  }

  public void setColorLocations(List<ProjectHistoryResponseColorLocations> colorLocations) {
    this.colorLocations = colorLocations;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectHistoryResponseActions projectHistoryResponseActions = (ProjectHistoryResponseActions) o;
    return Objects.equals(this.type, projectHistoryResponseActions.type) &&
        Objects.equals(this.submittedDate, projectHistoryResponseActions.submittedDate) &&
        Objects.equals(this.submittedBy, projectHistoryResponseActions.submittedBy) &&
        Objects.equals(this.comment, projectHistoryResponseActions.comment) &&
        Objects.equals(this.colorLocations, projectHistoryResponseActions.colorLocations);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, submittedDate, submittedBy, comment, colorLocations);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectHistoryResponseActions {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    submittedDate: ").append(toIndentedString(submittedDate)).append("\n");
    sb.append("    submittedBy: ").append(toIndentedString(submittedBy)).append("\n");
    sb.append("    comment: ").append(toIndentedString(comment)).append("\n");
    sb.append("    colorLocations: ").append(toIndentedString(colorLocations)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

