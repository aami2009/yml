package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProjectResponseAssignedUsers;
import io.swagger.model.ProjectResponseCartons;
import io.swagger.model.ProjectResponseColorLocationMap;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectResponse   {
  @JsonProperty("Id")
  private Long id = null;

  @JsonProperty("productId")
  private Long productId = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("assignedUsers")
  @Valid
  private List<ProjectResponseAssignedUsers> assignedUsers = null;

  @JsonProperty("cartons")
  @Valid
  private List<ProjectResponseCartons> cartons = null;

  @JsonProperty("code")
  private String code = null;

  @JsonProperty("colorLocationMap")
  @Valid
  private List<ProjectResponseColorLocationMap> colorLocationMap = null;

  @JsonProperty("releaseName")
  private String releaseName = null;

  @JsonProperty("modelNumber")
  private String modelNumber = null;

  public ProjectResponse id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProjectResponse productId(Long productId) {
    this.productId = productId;
    return this;
  }

  /**
   * Get productId
   * @return productId
  **/
  @ApiModelProperty(example = "894", value = "")


  public Long getProductId() {
    return productId;
  }

  public void setProductId(Long productId) {
    this.productId = productId;
  }

  public ProjectResponse type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(example = "LINE_EXTENSION", value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ProjectResponse status(String status) {
    this.status = status;
    return this;
  }

  /**
   * project status
   * @return status
  **/
  @ApiModelProperty(example = "pending", value = "project status")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public ProjectResponse assignedUsers(List<ProjectResponseAssignedUsers> assignedUsers) {
    this.assignedUsers = assignedUsers;
    return this;
  }

  public ProjectResponse addAssignedUsersItem(ProjectResponseAssignedUsers assignedUsersItem) {
    if (this.assignedUsers == null) {
      this.assignedUsers = new ArrayList<ProjectResponseAssignedUsers>();
    }
    this.assignedUsers.add(assignedUsersItem);
    return this;
  }

  /**
   * Get assignedUsers
   * @return assignedUsers
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectResponseAssignedUsers> getAssignedUsers() {
    return assignedUsers;
  }

  public void setAssignedUsers(List<ProjectResponseAssignedUsers> assignedUsers) {
    this.assignedUsers = assignedUsers;
  }

  public ProjectResponse cartons(List<ProjectResponseCartons> cartons) {
    this.cartons = cartons;
    return this;
  }

  public ProjectResponse addCartonsItem(ProjectResponseCartons cartonsItem) {
    if (this.cartons == null) {
      this.cartons = new ArrayList<ProjectResponseCartons>();
    }
    this.cartons.add(cartonsItem);
    return this;
  }

  /**
   * Get cartons
   * @return cartons
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectResponseCartons> getCartons() {
    return cartons;
  }

  public void setCartons(List<ProjectResponseCartons> cartons) {
    this.cartons = cartons;
  }

  public ProjectResponse code(String code) {
    this.code = code;
    return this;
  }

  /**
   * project code
   * @return code
  **/
  @ApiModelProperty(example = "456", value = "project code")


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ProjectResponse colorLocationMap(List<ProjectResponseColorLocationMap> colorLocationMap) {
    this.colorLocationMap = colorLocationMap;
    return this;
  }

  public ProjectResponse addColorLocationMapItem(ProjectResponseColorLocationMap colorLocationMapItem) {
    if (this.colorLocationMap == null) {
      this.colorLocationMap = new ArrayList<ProjectResponseColorLocationMap>();
    }
    this.colorLocationMap.add(colorLocationMapItem);
    return this;
  }

  /**
   * Get colorLocationMap
   * @return colorLocationMap
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProjectResponseColorLocationMap> getColorLocationMap() {
    return colorLocationMap;
  }

  public void setColorLocationMap(List<ProjectResponseColorLocationMap> colorLocationMap) {
    this.colorLocationMap = colorLocationMap;
  }

  public ProjectResponse releaseName(String releaseName) {
    this.releaseName = releaseName;
    return this;
  }

  /**
   * project release name
   * @return releaseName
  **/
  @ApiModelProperty(example = "Beats Pro", value = "project release name")


  public String getReleaseName() {
    return releaseName;
  }

  public void setReleaseName(String releaseName) {
    this.releaseName = releaseName;
  }

  public ProjectResponse modelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
    return this;
  }

  /**
   * project model number
   * @return modelNumber
  **/
  @ApiModelProperty(example = "789", value = "project model number")


  public String getModelNumber() {
    return modelNumber;
  }

  public void setModelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectResponse projectResponse = (ProjectResponse) o;
    return Objects.equals(this.id, projectResponse.id) &&
        Objects.equals(this.productId, projectResponse.productId) &&
        Objects.equals(this.type, projectResponse.type) &&
        Objects.equals(this.status, projectResponse.status) &&
        Objects.equals(this.assignedUsers, projectResponse.assignedUsers) &&
        Objects.equals(this.cartons, projectResponse.cartons) &&
        Objects.equals(this.code, projectResponse.code) &&
        Objects.equals(this.colorLocationMap, projectResponse.colorLocationMap) &&
        Objects.equals(this.releaseName, projectResponse.releaseName) &&
        Objects.equals(this.modelNumber, projectResponse.modelNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, productId, type, status, assignedUsers, cartons, code, colorLocationMap, releaseName, modelNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectResponse {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    assignedUsers: ").append(toIndentedString(assignedUsers)).append("\n");
    sb.append("    cartons: ").append(toIndentedString(cartons)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    colorLocationMap: ").append(toIndentedString(colorLocationMap)).append("\n");
    sb.append("    releaseName: ").append(toIndentedString(releaseName)).append("\n");
    sb.append("    modelNumber: ").append(toIndentedString(modelNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

