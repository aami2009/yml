package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProjectResponseCartons
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:02:55.134Z")

public class ProjectResponseCartons   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("projectMPN")
  private String projectMPN = null;

  @JsonProperty("location")
  private String location = null;

  @JsonProperty("color")
  private Long color = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("gs1Label")
  private Long gs1Label = null;

  @JsonProperty("snListLabel")
  private Long snListLabel = null;

  @JsonProperty("catonItem")
  @Valid
  private List<String> catonItem = null;

  @JsonProperty("validationStatus")
  private String validationStatus = null;

  public ProjectResponseCartons id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProjectResponseCartons projectMPN(String projectMPN) {
    this.projectMPN = projectMPN;
    return this;
  }

  /**
   * Get projectMPN
   * @return projectMPN
  **/
  @ApiModelProperty(example = "projectMPN", value = "")


  public String getProjectMPN() {
    return projectMPN;
  }

  public void setProjectMPN(String projectMPN) {
    this.projectMPN = projectMPN;
  }

  public ProjectResponseCartons location(String location) {
    this.location = location;
    return this;
  }

  /**
   * Get location
   * @return location
  **/
  @ApiModelProperty(example = "US", value = "")


  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public ProjectResponseCartons color(Long color) {
    this.color = color;
    return this;
  }

  /**
   * Get color
   * @return color
  **/
  @ApiModelProperty(example = "111", value = "")


  public Long getColor() {
    return color;
  }

  public void setColor(Long color) {
    this.color = color;
  }

  public ProjectResponseCartons description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
  **/
  @ApiModelProperty(example = "US, Black", value = "")


  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public ProjectResponseCartons gs1Label(Long gs1Label) {
    this.gs1Label = gs1Label;
    return this;
  }

  /**
   * Get gs1Label
   * @return gs1Label
  **/
  @ApiModelProperty(example = "789", value = "")


  public Long getGs1Label() {
    return gs1Label;
  }

  public void setGs1Label(Long gs1Label) {
    this.gs1Label = gs1Label;
  }

  public ProjectResponseCartons snListLabel(Long snListLabel) {
    this.snListLabel = snListLabel;
    return this;
  }

  /**
   * Get snListLabel
   * @return snListLabel
  **/
  @ApiModelProperty(example = "120", value = "")


  public Long getSnListLabel() {
    return snListLabel;
  }

  public void setSnListLabel(Long snListLabel) {
    this.snListLabel = snListLabel;
  }

  public ProjectResponseCartons catonItem(List<String> catonItem) {
    this.catonItem = catonItem;
    return this;
  }

  public ProjectResponseCartons addCatonItemItem(String catonItemItem) {
    if (this.catonItem == null) {
      this.catonItem = new ArrayList<String>();
    }
    this.catonItem.add(catonItemItem);
    return this;
  }

  /**
   * Get catonItem
   * @return catonItem
  **/
  @ApiModelProperty(value = "")


  public List<String> getCatonItem() {
    return catonItem;
  }

  public void setCatonItem(List<String> catonItem) {
    this.catonItem = catonItem;
  }

  public ProjectResponseCartons validationStatus(String validationStatus) {
    this.validationStatus = validationStatus;
    return this;
  }

  /**
   * Get validationStatus
   * @return validationStatus
  **/
  @ApiModelProperty(example = "pendingApproval", value = "")


  public String getValidationStatus() {
    return validationStatus;
  }

  public void setValidationStatus(String validationStatus) {
    this.validationStatus = validationStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProjectResponseCartons projectResponseCartons = (ProjectResponseCartons) o;
    return Objects.equals(this.id, projectResponseCartons.id) &&
        Objects.equals(this.projectMPN, projectResponseCartons.projectMPN) &&
        Objects.equals(this.location, projectResponseCartons.location) &&
        Objects.equals(this.color, projectResponseCartons.color) &&
        Objects.equals(this.description, projectResponseCartons.description) &&
        Objects.equals(this.gs1Label, projectResponseCartons.gs1Label) &&
        Objects.equals(this.snListLabel, projectResponseCartons.snListLabel) &&
        Objects.equals(this.catonItem, projectResponseCartons.catonItem) &&
        Objects.equals(this.validationStatus, projectResponseCartons.validationStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, projectMPN, location, color, description, gs1Label, snListLabel, catonItem, validationStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProjectResponseCartons {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    projectMPN: ").append(toIndentedString(projectMPN)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    color: ").append(toIndentedString(color)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    gs1Label: ").append(toIndentedString(gs1Label)).append("\n");
    sb.append("    snListLabel: ").append(toIndentedString(snListLabel)).append("\n");
    sb.append("    catonItem: ").append(toIndentedString(catonItem)).append("\n");
    sb.append("    validationStatus: ").append(toIndentedString(validationStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

