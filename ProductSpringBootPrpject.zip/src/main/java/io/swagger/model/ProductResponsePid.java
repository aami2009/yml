package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProductResponseAdmins;
import io.swagger.model.ProductResponsePidProjects;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProductResponsePid
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:04:05.089Z")

public class ProductResponsePid   {
  @JsonProperty("Id")
  private Long id = null;

  @JsonProperty("code")
  private String code = null;

  @JsonProperty("releaseName")
  private String releaseName = null;

  @JsonProperty("projects")
  @Valid
  private List<ProductResponsePidProjects> projects = null;

  @JsonProperty("admins")
  @Valid
  private List<ProductResponseAdmins> admins = null;

  public ProductResponsePid id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "23414", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProductResponsePid code(String code) {
    this.code = code;
    return this;
  }

  /**
   * Get code
   * @return code
  **/
  @ApiModelProperty(example = "B444", value = "")


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ProductResponsePid releaseName(String releaseName) {
    this.releaseName = releaseName;
    return this;
  }

  /**
   * Get releaseName
   * @return releaseName
  **/
  @ApiModelProperty(example = "PowerBeats Pro", value = "")


  public String getReleaseName() {
    return releaseName;
  }

  public void setReleaseName(String releaseName) {
    this.releaseName = releaseName;
  }

  public ProductResponsePid projects(List<ProductResponsePidProjects> projects) {
    this.projects = projects;
    return this;
  }

  public ProductResponsePid addProjectsItem(ProductResponsePidProjects projectsItem) {
    if (this.projects == null) {
      this.projects = new ArrayList<ProductResponsePidProjects>();
    }
    this.projects.add(projectsItem);
    return this;
  }

  /**
   * Get projects
   * @return projects
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProductResponsePidProjects> getProjects() {
    return projects;
  }

  public void setProjects(List<ProductResponsePidProjects> projects) {
    this.projects = projects;
  }

  public ProductResponsePid admins(List<ProductResponseAdmins> admins) {
    this.admins = admins;
    return this;
  }

  public ProductResponsePid addAdminsItem(ProductResponseAdmins adminsItem) {
    if (this.admins == null) {
      this.admins = new ArrayList<ProductResponseAdmins>();
    }
    this.admins.add(adminsItem);
    return this;
  }

  /**
   * Get admins
   * @return admins
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProductResponseAdmins> getAdmins() {
    return admins;
  }

  public void setAdmins(List<ProductResponseAdmins> admins) {
    this.admins = admins;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductResponsePid productResponsePid = (ProductResponsePid) o;
    return Objects.equals(this.id, productResponsePid.id) &&
        Objects.equals(this.code, productResponsePid.code) &&
        Objects.equals(this.releaseName, productResponsePid.releaseName) &&
        Objects.equals(this.projects, productResponsePid.projects) &&
        Objects.equals(this.admins, productResponsePid.admins);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, code, releaseName, projects, admins);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductResponsePid {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    releaseName: ").append(toIndentedString(releaseName)).append("\n");
    sb.append("    projects: ").append(toIndentedString(projects)).append("\n");
    sb.append("    admins: ").append(toIndentedString(admins)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

