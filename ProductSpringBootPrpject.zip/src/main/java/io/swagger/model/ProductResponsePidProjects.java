package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.ProductResponseAdmins;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ProductResponsePidProjects
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2020-07-03T15:04:05.089Z")

public class ProductResponsePidProjects   {
  @JsonProperty("id")
  private Long id = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("code")
  private String code = null;

  @JsonProperty("releaseName")
  private String releaseName = null;

  @JsonProperty("assignedUsers")
  @Valid
  private List<ProductResponseAdmins> assignedUsers = null;

  @JsonProperty("modelNumber")
  private String modelNumber = null;

  @JsonProperty("status")
  private String status = null;

  public ProductResponsePidProjects id(Long id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(example = "23423", value = "")


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public ProductResponsePidProjects type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(example = "LINE_EXTENSION", value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public ProductResponsePidProjects code(String code) {
    this.code = code;
    return this;
  }

  /**
   * Get code
   * @return code
  **/
  @ApiModelProperty(example = "B444", value = "")


  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ProductResponsePidProjects releaseName(String releaseName) {
    this.releaseName = releaseName;
    return this;
  }

  /**
   * Get releaseName
   * @return releaseName
  **/
  @ApiModelProperty(example = "", value = "")


  public String getReleaseName() {
    return releaseName;
  }

  public void setReleaseName(String releaseName) {
    this.releaseName = releaseName;
  }

  public ProductResponsePidProjects assignedUsers(List<ProductResponseAdmins> assignedUsers) {
    this.assignedUsers = assignedUsers;
    return this;
  }

  public ProductResponsePidProjects addAssignedUsersItem(ProductResponseAdmins assignedUsersItem) {
    if (this.assignedUsers == null) {
      this.assignedUsers = new ArrayList<ProductResponseAdmins>();
    }
    this.assignedUsers.add(assignedUsersItem);
    return this;
  }

  /**
   * Get assignedUsers
   * @return assignedUsers
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ProductResponseAdmins> getAssignedUsers() {
    return assignedUsers;
  }

  public void setAssignedUsers(List<ProductResponseAdmins> assignedUsers) {
    this.assignedUsers = assignedUsers;
  }

  public ProductResponsePidProjects modelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
    return this;
  }

  /**
   * Get modelNumber
   * @return modelNumber
  **/
  @ApiModelProperty(example = "A208", value = "")


  public String getModelNumber() {
    return modelNumber;
  }

  public void setModelNumber(String modelNumber) {
    this.modelNumber = modelNumber;
  }

  public ProductResponsePidProjects status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(example = "PENDING", value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductResponsePidProjects productResponsePidProjects = (ProductResponsePidProjects) o;
    return Objects.equals(this.id, productResponsePidProjects.id) &&
        Objects.equals(this.type, productResponsePidProjects.type) &&
        Objects.equals(this.code, productResponsePidProjects.code) &&
        Objects.equals(this.releaseName, productResponsePidProjects.releaseName) &&
        Objects.equals(this.assignedUsers, productResponsePidProjects.assignedUsers) &&
        Objects.equals(this.modelNumber, productResponsePidProjects.modelNumber) &&
        Objects.equals(this.status, productResponsePidProjects.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, type, code, releaseName, assignedUsers, modelNumber, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductResponsePidProjects {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    releaseName: ").append(toIndentedString(releaseName)).append("\n");
    sb.append("    assignedUsers: ").append(toIndentedString(assignedUsers)).append("\n");
    sb.append("    modelNumber: ").append(toIndentedString(modelNumber)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

